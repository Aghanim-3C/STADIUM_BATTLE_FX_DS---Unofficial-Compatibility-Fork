# Dramatic Shape Companion (for STADIUM_BATTLE_FX_DS)

Forwards the `VoxelState`, `OverworldBattle`, `Stadium` and `StadiumRom`
modules from whichever supported host mod is installed, under the id
`DRAMATIC_SHAPE_COMPANION`. Draws nothing of its own.

Supported hosts, tried in this order:

1. **DRAMATIC_SHAPE** -- full support: Stadium models, camera staging.
2. **BATTLE_ART_VOXEL_FORK** (absol89/DramaticShapeVoxelMod) -- camera
   staging only. This fork has no Stadium ROM extraction system at all, so
   Stadium models, hit reactions, faint hand-off, and attachment points
   are unavailable through it -- battles fall back to flat sprites for
   those, same as with no host installed, but with a working staged
   camera.

**Does not use the `DRAMALESS_SHAPE` id**, so no other mod that looks for
the real Dramaless Shape will find it by mistake. Use this together with
the `STADIUM_BATTLE_FX_DS` fork, which is the only one that knows to look
for this id instead of the original one.

## Installation

1. Either `DRAMATIC_SHAPE` or `BATTLE_ART_VOXEL_FORK` (your own install,
   unchanged).
2. This mod (`DRAMATIC_SHAPE_COMPANION`).
3. `STADIUM_BATTLE_FX_DS` (the fork, not the original `STADIUM_BATTLE_FX`).

Do not install the original `STADIUM_BATTLE_FX` at the same time: it has
the same behavior but looks for `DRAMALESS_SHAPE`, so it will never find
this companion and will run without live models/camera.

## Limits

- Less precise move attachment points (a generic bone instead of the exact
  one).
- No hit-reaction pose.
- No explicit control over faint disposition -- DRAMATIC_SHAPE (or its
  fork) still plays its own faint animation on its own regardless.
- Under `BATTLE_ART_VOXEL_FORK` specifically: no Stadium models at all, so
  everything Stadium-model-related (hit reactions, attachments, animated
  models) is unavailable -- only the staged camera works.

See the comments in `main.lua` for the full detail on what does and does
not carry over from each host.

## Credits

- **Dramaless Shape** (github.com/artyrambles/DRAMALESS_SHAPE) -- its
  authors and contributors designed and added the `Stadium.hit` /
  `Stadium.faint` public API that lets a companion effects mod request a
  skeletal reaction pose or hand off a faint disposition without reaching
  into a private battle-model session. This bridge exists specifically
  because that API isn't available outside Dramaless Shape; full credit to
  that project for the design this mod works around the absence of.
- **StadiumBattleFX** (github.com/anxiousintrovert/StadiumBattleFX) -- the
  mod this bridge exists to support, and the original source of the
  compatibility groundwork this whole chain builds on.
- The Stadium battle presentation concept this whole family of mods is
  built around originates from the original Stadium Battle mod by
  **rootbeerronin** (Discord).
