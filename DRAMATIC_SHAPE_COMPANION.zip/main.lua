-- Dramatic Shape companion for STADIUM_BATTLE_FX_DS (the DRAMATIC_SHAPE-
-- targeted fork of StadiumBattleFX).
--
-- This mod ships under its OWN id, DRAMATIC_SHAPE_COMPANION -- it does not
-- claim DRAMALESS_SHAPE, so it is invisible to any other mod that looks
-- for the real Dramaless Shape. STADIUM_BATTLE_FX_DS has been patched at
-- its three hardcoded companion lookups (main.lua, lib/EffectCacheScreen.lua,
-- lib/StadiumAssets.lua) to look for THIS id instead, and reads the same
-- shape of module off `found.exports.lib.require`: VoxelState,
-- OverworldBattle, Stadium, and StadiumRom (see
-- lib/DramaticShapeState.lua, DramaticShapeAttachment.lua,
-- DramaticShapeHit.lua, DramaticShapeFaint.lua and StadiumAssets.lua in
-- that fork).
--
-- Tries each known host in order and forwards whichever one is actually
-- installed:
--
--   1. DRAMATIC_SHAPE (1.8.x+) -- already exposes `mod.exports.lib = V`
--      with a `V.require(name)` loader, and its VoxelState/OverworldBattle/
--      Stadium modules already answer the exact functions StadiumBattleFX
--      reads:
--        VoxelState:      .level, .angle
--        OverworldBattle: .shot(), .ANCHOR, .backPinned(), .animScale(shot,x,y)
--        Stadium:         .mode(), .showing(side), .footprint(side)
--
--   2. BATTLE_ART_VOXEL_FORK (absol89/DramaticShapeVoxelMod) -- a separate,
--      unrelated fork (conflicts with both DRAMATIC_SHAPE and
--      DRAMALESS_SHAPE in its own manifest). Its VoxelState and
--      OverworldBattle modules match the same field/function names, so
--      camera staging (windup/travel/impact/recovery shots, the live
--      staged camera) works through it too. IMPORTANT: this fork has no
--      Stadium ROM extraction system at all -- no Stadium.lua,
--      StadiumRom.lua, StadiumMon/StadiumRig/StadiumPack, nothing --
--      so `require("Stadium")` and `require("StadiumRom")` simply return
--      nil under it. Every StadiumBattleFX caller already treats a missing
--      Stadium/StadiumRom module as the ordinary "older companion"
--      fallback case (fixed anchor point, no Stadium models, no hit
--      reaction, no faint hand-off, no attachment points) -- exactly what
--      happens with no Dramatic-family mod installed at all, just with a
--      working staged camera on top.
--
-- What NEITHER host has is DRAMALESS_SHAPE's newer Stadium.attachment /
-- .center / .attachmentTags / .hit / .faint API (the per-bone attachment
-- points, the hit-reaction pose, and the faint disposition hook) -- those
-- functions were added specifically to Dramaless Shape and aren't present
-- upstream. Every caller on the StadiumBattleFX side already falls back
-- gracefully when they're missing, so this bridge does not need to invent
-- them: forwarding the modules above is enough for animated Stadium-model
-- battles (DRAMATIC_SHAPE only) and staged camera work (either host) to
-- work. Hit reactions and the HP-drain-synced faint hand-off simply stay
-- off -- DRAMATIC_SHAPE already plays its own faint animation on its own,
-- and BATTLE_ART_VOXEL_FORK has no Stadium models to react in the first
-- place.
--
-- Credit: the Stadium.hit / Stadium.faint public API this bridge would
-- otherwise need to reinvent was designed and contributed to Dramaless
-- Shape (github.com/artyrambles/DRAMALESS_SHAPE) by its authors and
-- contributors, so that StadiumBattleFX could request a reaction pose
-- without reaching into a private model session. This bridge exists
-- because those two specific functions aren't available outside Dramaless
-- Shape -- full credit to that project for the design.

local mod = ...

-- Tried in order; the first one found is used. DRAMATIC_SHAPE and
-- BATTLE_ART_VOXEL_FORK both list each other (and DRAMALESS_SHAPE) as
-- conflicting in their own manifests, so at most one of these is ever
-- actually installed -- no ambiguity in picking whichever resolves first.
local CANDIDATE_IDS = { "DRAMATIC_SHAPE", "BATTLE_ART_VOXEL_FORK" }

-- Resolved lazily and on every call rather than once at load time: mod load
-- order between this bridge and its host is not guaranteed, but every
-- real StadiumBattleFX call into this happens later, from a battle event,
-- by which point every mod is loaded.
local function realShape()
  for _, id in ipairs(CANDIDATE_IDS) do
    local found = mod.find(id)
    if found then return found, id end
  end
  if mod.log then
    mod.log:warn(
      "None of [" .. table.concat(CANDIDATE_IDS, ", ") .. "] are installed "
      .. "or enabled -- this bridge does nothing without one of them. "
      .. "Install/enable DRAMATIC_SHAPE for full Stadium-model support, or "
      .. "BATTLE_ART_VOXEL_FORK for camera staging only.")
  end
  return nil
end

local warnedOnce = false

mod.exports.lib = {
  require = function(name)
    local found, hostId = realShape()
    local lib = found and found.exports and found.exports.lib
    if not (lib and type(lib.require) == "function") then
      if not warnedOnce and mod.log then
        mod.log:warn(
          tostring(hostId) .. " has no usable exports.lib -- is it an old "
          .. "version? This bridge needs a host build that exports "
          .. "mod.exports.lib.")
        warnedOnce = true
      end
      return nil
    end
    -- Straight passthrough. STADIUM_BATTLE_FX_DS only ever asks this for
    -- "VoxelState", "OverworldBattle", "Stadium" and "StadiumRom" -- see
    -- the header comment above for exactly what each host answers and
    -- what does and does not carry over.
    local ok, value = pcall(lib.require, name)
    if not ok then return nil end
    return value
  end,
}

-- Cosmetic only: some UI surfaces may show a companion's own reported
-- version. Passed through rather than hardcoded so it tracks whichever
-- host build is actually installed.
mod.exports.version = function()
  local found = realShape()
  local v = found and found.exports and found.exports.version
  return type(v) == "string" and v or "unknown (via bridge)"
end

if mod.log then
  local found, hostId = realShape()
  mod.log:info(
    "Dramatic Shape <-> StadiumBattleFX bridge loaded. "
    .. (hostId and ("Forwarding to " .. hostId .. ".") or "No supported host found yet."))
end
